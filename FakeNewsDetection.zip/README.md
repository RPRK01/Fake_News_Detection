
# Fake News Detection

This project detects whether a news article is Fake or Real using a Naive Bayes classifier with TF-IDF vectorization.

## Features
- Train a model using Fake.csv and True.csv datasets.
- Predict new news articles as "Fake" or "Real".
- Easy to run and extend.

## Tech Stack
- Python 3
- Pandas
- Scikit-learn
- Optional: Flask for web app

## How to Run
1. Clone the repository:
```
git clone <repo_link>
```
2. Install dependencies:
```
pip install -r requirements.txt
```
3. Place Fake.csv and True.csv in the data/ folder.
4. Run:
```
python fake_news_detection.py
```
5. Test with your own news text by changing the news variable.

## Dataset
- Fake.csv – fake news articles
- True.csv – real news articles
- Datasets can be downloaded from [Kaggle](https://www.kaggle.com/datasets/clmentbisaillon/fake-and-real-news-dataset)

## Output
- Model Accuracy
- Fake/Real prediction for a sample news article
